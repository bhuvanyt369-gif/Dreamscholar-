import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ImpactCards from './components/ImpactCards';
import AboutMission from './components/AboutMission';
import Projects from './components/Projects';
import Donate from './components/Donate';
import ContactForm from './components/ContactForm';
import VolunteerForm from './components/VolunteerForm';
import AdminDashboard from './components/AdminDashboard';
import NewsletterSignup from './components/NewsletterSignup';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ToastContainer from './components/ToastContainer';
import { useToast } from './hooks/useToast';
import { Button } from './components/ui/button';

const App = () => {
  const [showAdmin, setShowAdmin] = useState(false);
  const { toasts, removeToast } = useToast();

  // Admin access check (simple password for demo)
  const checkAdminAccess = () => {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
      setShowAdmin(true);
    } else if (password !== null) {
      alert('Incorrect password. Please try again.');
    }
  };

  // Toggle admin view with keyboard shortcut (Ctrl+Shift+A)
  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        checkAdminAccess();
      }
    };
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  if (showAdmin) {
    return (
      <div className="min-h-screen dark:bg-gray-900 bg-gray-50">
        <div className="dark:bg-gray-800 bg-white border-b dark:border-gray-700 border-gray-200 p-4">
          <div className="max-w-6xl mx-auto flex justify-between items-center">
            <h1 className="text-xl font-bold dark:text-white">HopeBridge Admin Dashboard</h1>
            <Button onClick={() => setShowAdmin(false)} variant="outline" className="dark:hover:bg-gray-700">
              Back to Site
            </Button>
          </div>
        </div>
        <AdminDashboard />
      </div>
    );
  }

  return (
    <div className="min-h-screen dark:bg-gray-900 bg-white">
      <Header />
      <main>
        <Hero />
        <ImpactCards />
        <AboutMission />
        <Projects />
        <Donate />
        
        {/* Newsletter Section */}
        <section className="py-16 px-4 dark:bg-gray-800 bg-gray-50">
          <div className="max-w-md mx-auto">
            <NewsletterSignup />
          </div>
        </section>

        {/* Volunteer Section */}
        <section id="volunteer" className="py-16 px-4 dark:bg-gray-900 bg-white">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 dark:text-white">Become a Volunteer</h2>
              <p className="text-lg dark:text-gray-300 text-gray-600 max-w-2xl mx-auto">
                Join our team of dedicated volunteers making a real difference in communities across India.
              </p>
            </div>
            <VolunteerForm />
          </div>
        </section>

        {/* Contact Section */}
        <Contact />

        {/* Contact Form Section */}
        <section className="py-16 px-4 dark:bg-gray-800 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 dark:text-white">Send Us a Message</h2>
              <p className="text-lg dark:text-gray-300 text-gray-600 max-w-2xl mx-auto">
                Have questions? Want to learn more? Fill out the form below and we'll get back to you soon.
              </p>
            </div>
            <ContactForm />
          </div>
        </section>

        <Gallery />
      </main>
      <Footer />
      
      {/* Admin Access Button (hidden by default) */}
      <button
        onClick={checkAdminAccess}
        className="fixed bottom-4 right-4 dark:bg-gray-800 bg-gray-800 text-white p-2 rounded-full opacity-50 hover:opacity-100 transition-opacity text-xs"
        title="Admin Access (Ctrl+Shift+A)"
      >
        Admin
      </button>

      {/* Floating Social Media Button */}
      <a
        href="https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg=="
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-4 left-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white p-3 rounded-full shadow-lg hover:scale-110 transition-transform z-40"
        title="Follow us on Instagram"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.667.07-4.947.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zM5.838 12a6.162 6.162 0 1 1 12.324 0 6.162 6.162 0 0 1-12.324 0zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm4.965-10.405a1.44 1.44 0 1 1 2.881.001 1.44 1.44 0 0 1-2.881-.001z"/>
        </svg>
      </a>

      {/* Toast Container */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
};

export default App;