import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Progress } from '../components/ui/progress';
import { TrendingUp, Users, Target, Heart, Award, Calendar } from 'lucide-react';

interface DonationData {
  total: number;
  count: number;
  monthlyGoal: number;
  recentDonations: Array<{
    amount: number;
    timestamp: string;
    type: string;
  }>;
}

const DonationTracker = () => {
  const [donationData, setDonationData] = useState<DonationData>({
    total: 0,
    count: 0,
    monthlyGoal: 100000,
    recentDonations: []
  });
  const [customAmount, setCustomAmount] = useState('');
  const [showThankYou, setShowThankYou] = useState(false);

  useEffect(() => {
    // Load data from localStorage
    const saved = localStorage.getItem('hopeBridgeDonations');
    if (saved) {
      setDonationData(JSON.parse(saved));
    } else {
      // Initialize with some demo data
      const initialData = {
        total: 25000,
        count: 45,
        monthlyGoal: 100000,
        recentDonations: [
          { amount: 1000, timestamp: new Date(Date.now() - 3600000).toISOString(), type: 'monthly' },
          { amount: 500, timestamp: new Date(Date.now() - 7200000).toISOString(), type: 'one-time' },
          { amount: 2000, timestamp: new Date(Date.now() - 10800000).toISOString(), type: 'one-time' }
        ]
      };
      setDonationData(initialData);
      localStorage.setItem('hopeBridgeDonations', JSON.stringify(initialData));
    }
  }, []);

  const recordDonation = (amount: number, type: 'one-time' | 'monthly') => {
    const newDonation = {
      amount,
      timestamp: new Date().toISOString(),
      type
    };

    const updatedData = {
      ...donationData,
      total: donationData.total + amount,
      count: donationData.count + 1,
      recentDonations: [newDonation, ...donationData.recentDonations].slice(0, 10)
    };
    
    setDonationData(updatedData);
    localStorage.setItem('hopeBridgeDonations', JSON.stringify(updatedData));
    
    // Open UPI app
    window.location.href = `upi://pay?pa=7702479214@fam&pn=HopeBridge&am=${amount}&cu=INR`;
    
    setShowThankYou(true);
    setTimeout(() => setShowThankYou(false), 3000);
  };

  const handleCustomDonation = () => {
    const amount = parseFloat(customAmount);
    if (amount > 0) {
      recordDonation(amount, 'one-time');
      setCustomAmount('');
    }
  };

  const progressPercentage = Math.min(100, Math.round((donationData.total / donationData.monthlyGoal) * 100));

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Total Raised</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">₹{donationData.total.toLocaleString()}</div>
            <p className="text-xs text-blue-600">This month</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Total Donors</CardTitle>
            <Users className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{donationData.count}</div>
            <p className="text-xs text-green-600">Amazing supporters</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Goal Progress</CardTitle>
            <Target className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{progressPercentage}%</div>
            <p className="text-xs text-purple-600">Of ₹{donationData.monthlyGoal.toLocaleString()} goal</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Avg Donation</CardTitle>
            <Heart className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              ₹{donationData.count > 0 ? Math.round(donationData.total / donationData.count).toLocaleString() : 0}
            </div>
            <p className="text-xs text-orange-600">Per donor</p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-500" />
            Monthly Goal Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>₹{donationData.total.toLocaleString()} raised</span>
              <span>₹{donationData.monthlyGoal.toLocaleString()} goal</span>
            </div>
            <Progress value={progressPercentage} className="h-3" />
            <p className="text-xs text-gray-500 text-center">
              ₹{(donationData.monthlyGoal - donationData.total).toLocaleString()} more to go!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Donations */}
      {donationData.recentDonations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-500" />
              Recent Donations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {donationData.recentDonations.map((donation, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">
                    {new Date(donation.timestamp).toLocaleDateString()} • {donation.type}
                  </span>
                  <span className="font-semibold text-green-600">₹{donation.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Thank You Message */}
      {showThankYou && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="text-center p-4">
            <Heart className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-green-700 font-bold">Thank you for your generous donation!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DonationTracker;