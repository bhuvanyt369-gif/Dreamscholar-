import React, { useState, useEffect } from 'react';
import { Menu, X, Heart, Instagram, Facebook, Twitter } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Donate', href: '#donate' },
    { name: 'Volunteer', href: '#volunteer' },
    { name: 'Contact', href: '#contact' }
  ];

  const socialLinks = [
    {
      icon: Instagram,
      url: 'https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg==',
      label: 'Instagram'
    },
    {
      icon: Facebook,
      url: 'https://facebook.com/hopebridgefoundation',
      label: 'Facebook'
    },
    {
      icon: Twitter,
      url: 'https://twitter.com/hopebridge_fdn',
      label: 'Twitter'
    }
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'dark:bg-gray-900/95 dark:backdrop-blur-lg bg-white/95 backdrop-blur-lg shadow-lg'
          : 'dark:bg-gray-900/90 dark:backdrop-blur-md bg-white/90 backdrop-blur-md'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Heart className="w-8 h-8 text-red-500" />
            <span className="text-xl font-bold dark:text-white text-gray-900">HopeBridge</span>
            <span className="text-sm dark:text-gray-400 text-gray-500 hidden sm:inline">Foundation</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="dark:text-gray-300 text-gray-700 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition-colors duration-200 relative group"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Desktop Right Side */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Theme Toggle */}
            <ThemeToggle />
            
            {/* Social Links */}
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="dark:text-gray-400 text-gray-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                  aria-label={social.label}
                >
                  <Icon className="w-5 h-5" />
                </a>
              );
            })}
            
            {/* CTA Button */}
            <a
              href="#donate"
              onClick={(e) => handleNavClick(e, '#donate')}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium"
            >
              Donate Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 md:hidden">
            <ThemeToggle />
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="dark:text-gray-300 text-gray-700 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden dark:bg-gray-900 bg-white border-t dark:border-gray-800 border-gray-200">
            <nav className="py-4 space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="block px-4 py-2 dark:text-gray-300 text-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition-colors"
                >
                  {link.name}
                </a>
              ))}
              
              {/* Mobile Social Links */}
              <div className="px-4 py-3 dark:border-gray-800 border-t border-gray-200">
                <p className="text-sm dark:text-gray-400 text-gray-600 mb-3">Follow Us</p>
                <div className="flex space-x-4">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={social.label}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="dark:text-gray-400 text-gray-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                        aria-label={social.label}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
              
              {/* Mobile CTA */}
              <div className="px-4 py-3 dark:border-gray-800 border-t border-gray-200">
                <a
                  href="#donate"
                  onClick={(e) => handleNavClick(e, '#donate')}
                  className="block w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium text-center"
                >
                  Donate Now
                </a>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;