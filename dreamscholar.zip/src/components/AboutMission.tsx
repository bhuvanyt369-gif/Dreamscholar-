import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Heart, BookOpen, Users, Home } from 'lucide-react';

const AboutMission = () => {
  const missionItems = [
    { icon: Users, text: "Helping poor families build sustainable futures" },
    { icon: Heart, text: "Saving children's lives through healthcare" },
    { icon: BookOpen, text: "Providing quality education to every child" },
    { icon: Home, text: "Community development and empowerment" }
  ];

  return (
    <section id="about" className="py-16 dark:bg-gray-800 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* About Us */}
          <div>
            <h3 className="text-2xl font-bold mb-4 dark:text-white text-indigo-700">Who We Are</h3>
            <p className="dark:text-gray-300 text-gray-600 leading-relaxed mb-4">
              HopeBridge Foundation was born from a simple belief: every child deserves a chance to thrive. 
              Founded in 2015, we began our journey in the rural heartlands of Madhya Pradesh, 
              witnessing firsthand the challenges faced by underserved communities.
            </p>
            <p className="dark:text-gray-300 text-gray-600 leading-relaxed">
              Today, we're a team of dedicated volunteers and professionals working tirelessly to bridge 
              the gap between privilege and possibility, bringing hope where it's needed most.
            </p>
          </div>

          {/* Our Mission */}
          <div>
            <h3 className="text-2xl font-bold mb-4 dark:text-white text-indigo-700">Our Mission</h3>
            <Card className="dark:bg-gray-700 dark:border-gray-600 border-gray-200 bg-white">
              <CardContent className="p-6">
                {missionItems.map((item, index) => (
                  <div key={index} className="flex items-start mb-4 last:mb-0">
                    <item.icon className="w-5 h-5 text-rose-500 mr-3 mt-1 flex-shrink-0" />
                    <span className="dark:text-gray-300 text-gray-600">{item.text}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutMission;