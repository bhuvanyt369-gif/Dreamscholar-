import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Mail, Send, CheckCircle, Bell } from 'lucide-react';

const NewsletterSignup = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Save to localStorage
    const subscribers = JSON.parse(localStorage.getItem('hopeBridgeSubscribers') || '[]');
    subscribers.push({
      email,
      timestamp: new Date().toISOString(),
      id: Date.now()
    });
    localStorage.setItem('hopeBridgeSubscribers', JSON.stringify(subscribers));

    // Send notification email
    const subject = `New Newsletter Subscription: ${email}`;
    const body = `Email: ${email}\nTimestamp: ${new Date().toISOString()}`;
    window.location.href = `mailto:099bhuvan@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    setTimeout(() => {
      setIsSubscribed(true);
      setIsSubmitting(false);
      setEmail('');
    }, 1000);
  };

  if (isSubscribed) {
    return (
      <Card className="border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800">
        <CardContent className="text-center p-6">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-green-800 dark:text-green-400 mb-2">Successfully Subscribed!</h3>
          <p className="text-green-600 dark:text-green-300 text-sm">Thank you for joining our community. You'll receive updates about our work.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700 border-blue-200 dark:border-gray-600">
      <CardHeader>
        <CardTitle className="text-center flex items-center justify-center gap-2 dark:text-white">
          <Bell className="w-5 h-5 text-blue-600" />
          Stay Connected
        </CardTitle>
        <p className="text-center text-sm dark:text-gray-300 text-gray-600">
          Get updates on our impact and upcoming events
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubscribe} className="space-y-4">
          <div>
            <Label htmlFor="newsletter-email" className="dark:text-gray-300">Email Address</Label>
            <Input
              id="newsletter-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="your@email.com"
              className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Subscribing...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Subscribe to Newsletter
              </>
            )}
          </Button>
        </form>
        <p className="text-xs dark:text-gray-400 text-gray-500 text-center mt-4">
          We respect your privacy. Unsubscribe at any time.
        </p>
      </CardContent>
    </Card>
  );
};

export default NewsletterSignup;