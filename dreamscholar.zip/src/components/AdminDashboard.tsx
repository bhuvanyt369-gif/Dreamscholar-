import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Users, Mail, Heart, TrendingUp, Calendar, Download, Eye, Trash2 } from 'lucide-react';

interface Contact {
  id: number;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  timestamp: string;
}

interface Volunteer {
  id: number;
  name: string;
  email: string;
  phone: string;
  location: string;
  interest: string;
  availability: string;
  status: string;
  timestamp: string;
}

interface Donation {
  amount: number;
  type: string;
  timestamp: string;
}

interface Subscriber {
  id: number;
  email: string;
  timestamp: string;
}

const AdminDashboard = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [volunteers, setVolunteers] = useState<Volunteer[]>([]);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'contacts' | 'volunteers' | 'donations' | 'subscribers'>('overview');

  useEffect(() => {
    // Load data from localStorage
    const loadedContacts = JSON.parse(localStorage.getItem('hopeBridgeContacts') || '[]');
    const loadedVolunteers = JSON.parse(localStorage.getItem('hopeBridgeVolunteers') || '[]');
    const loadedDonations = JSON.parse(localStorage.getItem('hopeBridgeDonations') || '{}');
    const loadedSubscribers = JSON.parse(localStorage.getItem('hopeBridgeSubscribers') || '[]');

    setContacts(loadedContacts);
    setVolunteers(loadedVolunteers);
    setDonations(loadedDonations.recentDonations || []);
    setSubscribers(loadedSubscribers);
  }, []);

  const exportData = (type: string, data: any[]) => {
    const csv = [
      Object.keys(data[0] || {}).join(','),
      ...data.map(item => Object.values(item).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const deleteItem = (type: string, id: number) => {
    if (confirm('Are you sure you want to delete this item?')) {
      if (type === 'contacts') {
        setContacts(prev => prev.filter(item => item.id !== id));
        localStorage.setItem('hopeBridgeContacts', JSON.stringify(contacts.filter(item => item.id !== id)));
      } else if (type === 'volunteers') {
        setVolunteers(prev => prev.filter(item => item.id !== id));
        localStorage.setItem('hopeBridgeVolunteers', JSON.stringify(volunteers.filter(item => item.id !== id)));
      } else if (type === 'subscribers') {
        setSubscribers(prev => prev.filter(item => item.id !== id));
        localStorage.setItem('hopeBridgeSubscribers', JSON.stringify(subscribers.filter(item => item.id !== id)));
      }
    }
  };

  const totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
  const monthlyDonations = donations.filter(d => {
    const date = new Date(d.timestamp);
    const now = new Date();
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  }).reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 dark:text-white">Admin Dashboard</h1>
      
      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-6 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'contacts', label: 'Contacts' },
          { id: 'volunteers', label: 'Volunteers' },
          { id: 'donations', label: 'Donations' },
          { id: 'subscribers', label: 'Subscribers' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-md transition-colors ${
              activeTab === tab.id
                ? 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400 shadow'
                : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium dark:text-gray-300">Total Contacts</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold dark:text-white">{contacts.length}</div>
              <p className="text-xs text-muted-foreground dark:text-gray-400">Messages received</p>
            </CardContent>
          </Card>

          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium dark:text-gray-300">Volunteers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold dark:text-white">{volunteers.length}</div>
              <p className="text-xs text-muted-foreground dark:text-gray-400">Applications received</p>
            </CardContent>
          </Card>

          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium dark:text-gray-300">Total Donations</CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold dark:text-white">₹{totalDonations.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground dark:text-gray-400">Lifetime total</p>
            </CardContent>
          </Card>

          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium dark:text-gray-300">Monthly Donations</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold dark:text-white">₹{monthlyDonations.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground dark:text-gray-400">This month</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Contacts Tab */}
      {activeTab === 'contacts' && (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="dark:text-white">Contact Messages</CardTitle>
              <Button onClick={() => exportData('contacts', contacts)} className="dark:hover:bg-gray-700">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {contacts.length === 0 ? (
              <p className="text-center py-8 dark:text-gray-400">No contacts yet</p>
            ) : (
              <div className="space-y-4">
                {contacts.map((contact) => (
                  <div key={contact.id} className="border dark:border-gray-600 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-semibold dark:text-white">{contact.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{contact.email} • {contact.phone}</p>
                        <p className="text-sm font-medium mt-2 dark:text-gray-300">{contact.subject}</p>
                        <p className="text-sm mt-1 dark:text-gray-400">{contact.message}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                          {new Date(contact.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="dark:hover:bg-gray-700">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => deleteItem('contacts', contact.id)}
                          className="dark:hover:bg-gray-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Volunteers Tab */}
      {activeTab === 'volunteers' && (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="dark:text-white">Volunteer Applications</CardTitle>
              <Button onClick={() => exportData('volunteers', volunteers)} className="dark:hover:bg-gray-700">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {volunteers.length === 0 ? (
              <p className="text-center py-8 dark:text-gray-400">No volunteer applications yet</p>
            ) : (
              <div className="space-y-4">
                {volunteers.map((volunteer) => (
                  <div key={volunteer.id} className="border dark:border-gray-600 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-semibold dark:text-white">{volunteer.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{volunteer.email} • {volunteer.phone}</p>
                        <p className="text-sm dark:text-gray-300 mt-2">
                          <span className="font-medium">Location:</span> {volunteer.location}
                        </p>
                        <p className="text-sm dark:text-gray-300">
                          <span className="font-medium">Interest:</span> {volunteer.interest}
                        </p>
                        <p className="text-sm dark:text-gray-300">
                          <span className="font-medium">Availability:</span> {volunteer.availability}
                        </p>
                        <span className={`inline-block px-2 py-1 text-xs rounded-full mt-2 ${
                          volunteer.status === 'pending' 
                            ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                            : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        }`}>
                          {volunteer.status}
                        </span>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                          {new Date(volunteer.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="dark:hover:bg-gray-700">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => deleteItem('volunteers', volunteer.id)}
                          className="dark:hover:bg-gray-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Donations Tab */}
      {activeTab === 'donations' && (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="dark:text-white">Recent Donations</CardTitle>
              <Button onClick={() => exportData('donations', donations)} className="dark:hover:bg-gray-700">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {donations.length === 0 ? (
              <p className="text-center py-8 dark:text-gray-400">No donations yet</p>
            ) : (
              <div className="space-y-4">
                {donations.map((donation, index) => (
                  <div key={index} className="border dark:border-gray-600 p-4 rounded-lg">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-semibold dark:text-white">₹{donation.amount}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{donation.type}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                          {new Date(donation.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <Heart className="w-5 h-5 text-red-500" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Subscribers Tab */}
      {activeTab === 'subscribers' && (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="dark:text-white">Newsletter Subscribers</CardTitle>
              <Button onClick={() => exportData('subscribers', subscribers)} className="dark:hover:bg-gray-700">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {subscribers.length === 0 ? (
              <p className="text-center py-8 dark:text-gray-400">No subscribers yet</p>
            ) : (
              <div className="space-y-4">
                {subscribers.map((subscriber) => (
                  <div key={subscriber.id} className="border dark:border-gray-600 p-4 rounded-lg">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-semibold dark:text-white">{subscriber.email}</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                          {new Date(subscriber.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => deleteItem('subscribers', subscriber.id)}
                        className="dark:hover:bg-gray-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AdminDashboard;