import React, { useState } from 'react';
import { Heart, MessageCircle, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';

interface GalleryItem {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  likes: number;
  dislikes: number;
  comments: string[];
  liked: boolean;
  disliked: boolean;
}

const Gallery = () => {
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([
    {
      id: 1,
      title: "Food Distribution Drive",
      description: "Volunteers distributing meals to 200+ families in rural Madhya Pradesh",
      imageUrl: "https://photos.app.goo.gl/tdW4BzoLc9WfgmpY9",
      likes: 45,
      dislikes: 2,
      comments: ["Amazing work!", "Keep it up!"],
      liked: false,
      disliked: false
    },
    {
      id: 2,
      title: "School Supplies Distribution",
      description: "Children receiving new books and uniforms for the academic year",
      imageUrl: "https://photos.app.goo.gl/ZMwY5V8vHFK52uPa6",
      likes: 62,
      dislikes: 1,
      comments: ["These smiles say it all!", "Education is power"],
      liked: false,
      disliked: false
    },
    {
      id: 3,
      title: "Medical Camp Success",
      description: "Free health check-ups for 150+ villagers with doctor consultations",
      imageUrl: "https://photos.app.goo.gl/kzVfWKaemXSrQp739",
      likes: 38,
      dislikes: 0,
      comments: ["Healthcare for all!", "Thank you doctors"],
      liked: false,
      disliked: false
    },
    {
      id: 4,
      title: "Clean Water Initiative",
      description: "Installing water purification systems in remote villages",
      imageUrl: "https://photos.app.goo.gl/fZu2JedbuxxQ6U4z9",
      likes: 71,
      dislikes: 3,
      comments: ["Clean water saves lives!", "Great initiative"],
      liked: false,
      disliked: false
    },
    {
      id: 5,
      title: "Women Empowerment Workshop",
      description: "Training programs for sustainable livelihood and skill development",
      imageUrl: "https://photos.app.goo.gl/wHxnYmHNKFUNKJcK9",
      likes: 56,
      dislikes: 1,
      comments: ["Empowering women!", "Skills for life"],
      liked: false,
      disliked: false
    }
  ]);

  const [commentInputs, setCommentInputs] = useState<{ [key: number]: string }>({});
  const [showComments, setShowComments] = useState<{ [key: number]: boolean }>({});

  const handleLike = (id: number) => {
    setGalleryItems(items => 
      items.map(item => {
        if (item.id === id) {
          if (item.liked) {
            return { ...item, liked: false, likes: item.likes - 1 };
          } else {
            return { 
              ...item, 
              liked: true, 
              likes: item.likes + 1,
              disliked: false,
              dislikes: item.disliked ? item.dislikes - 1 : item.dislikes
            };
          }
        }
        return item;
      })
    );
  };

  const handleDislike = (id: number) => {
    setGalleryItems(items => 
      items.map(item => {
        if (item.id === id) {
          if (item.disliked) {
            return { ...item, disliked: false, dislikes: item.dislikes - 1 };
          } else {
            return { 
              ...item, 
              disliked: true, 
              dislikes: item.dislikes + 1,
              liked: false,
              likes: item.liked ? item.likes - 1 : item.likes
            };
          }
        }
        return item;
      })
    );
  };

  const handleAddComment = (id: number) => {
    const comment = commentInputs[id]?.trim();
    if (comment) {
      setGalleryItems(items => 
        items.map(item => 
          item.id === id 
            ? { ...item, comments: [...item.comments, comment] }
            : item
        )
      );
      setCommentInputs({ ...commentInputs, [id]: '' });
    }
  };

  const toggleComments = (id: number) => {
    setShowComments({ ...showComments, [id]: !showComments[id] });
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-indigo-700">
          In Our Community
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {galleryItems.map((item) => (
            <Card key={item.id} className="bg-gray-50 border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
              {/* Real Photo */}
              <div className="relative h-64 overflow-hidden group">
                <img 
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  onError={(e) => {
                    // Fallback to placeholder if image fails to load
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    target.nextElementSibling?.classList.remove('hidden');
                  }}
                />
                {/* Fallback placeholder */}
                <div className="hidden absolute inset-0 bg-gradient-to-br from-slate-300 to-slate-400 flex items-center justify-center">
                  <div className="text-center">
                    <Heart className="w-12 h-12 mx-auto mb-2 text-rose-500" />
                    <p className="text-slate-700 font-medium">{item.title}</p>
                  </div>
                </div>
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="text-white font-semibold bg-black/50 px-3 py-1 rounded">View Details</span>
                </div>
              </div>
              
              <CardContent className="p-4">
                <h3 className="font-semibold text-slate-800 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{item.description}</p>
                
                {/* Engagement Buttons */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(item.id)}
                      className={`flex items-center space-x-1 ${item.liked ? 'text-teal-600' : 'text-gray-500'}`}
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span className="text-sm">{item.likes}</span>
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDislike(item.id)}
                      className={`flex items-center space-x-1 ${item.disliked ? 'text-rose-500' : 'text-gray-500'}`}
                    >
                      <ThumbsDown className="w-4 h-4" />
                      <span className="text-sm">{item.dislikes}</span>
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleComments(item.id)}
                      className="flex items-center space-x-1 text-gray-500"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{item.comments.length}</span>
                    </Button>
                  </div>
                </div>
                
                {/* Comments Section */}
                {showComments[item.id] && (
                  <div className="border-t border-gray-200 pt-3">
                    <div className="space-y-2 mb-3 max-h-32 overflow-y-auto">
                      {item.comments.map((comment, index) => (
                        <div key={index} className="text-sm text-gray-600 bg-gray-100 p-2 rounded">
                          {comment}
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        placeholder="Add a comment..."
                        value={commentInputs[item.id] || ''}
                        onChange={(e) => setCommentInputs({ ...commentInputs, [item.id]: e.target.value })}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddComment(item.id)}
                        className="flex-1 px-3 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />
                      <Button
                        size="sm"
                        onClick={() => handleAddComment(item.id)}
                        className="bg-teal-600 hover:bg-teal-700 text-white"
                      >
                        Post
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;