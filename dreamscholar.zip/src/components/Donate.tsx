import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Heart, Copy, Check, IndianRupee, TrendingUp, Users, Target } from 'lucide-react';
import { useToast } from '../hooks/useToast';

const Donate = () => {
  const [copied, setCopied] = useState(false);
  const [customAmount, setCustomAmount] = useState('');
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const { success, error } = useToast();

  const upiId = '7702479214@fam';

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(upiId);
      setCopied(true);
      success('UPI ID copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      error('Failed to copy UPI ID');
    }
  };

  const handleDonation = (amount: number, type: 'one-time' | 'monthly') => {
    setSelectedAmount(amount);
    
    // Save donation to localStorage
    const donations = JSON.parse(localStorage.getItem('hopeBridgeDonations') || '{}');
    const newDonation = {
      amount,
      type,
      timestamp: new Date().toISOString()
    };
    
    if (!donations.recentDonations) {
      donations.recentDonations = [];
    }
    
    donations.recentDonations.unshift(newDonation);
    donations.total = (donations.total || 0) + amount;
    donations.count = (donations.count || 0) + 1;
    
    localStorage.setItem('hopeBridgeDonations', JSON.stringify(donations));
    
    // Open UPI app
    const upiUrl = `upi://pay?pa=${upiId}&pn=HopeBridge%20Foundation&am=${amount}&cu=INR&tn=Donation%20for%20HopeBridge`;
    
    // Try to open UPI app
    const link = document.createElement('a');
    link.href = upiUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    success(`Opening payment app for ₹${amount} donation...`);
  };

  const handleCustomDonation = () => {
    const amount = parseFloat(customAmount);
    if (amount && amount > 0) {
      handleDonation(amount, 'one-time');
    } else {
      error('Please enter a valid amount');
    }
  };

  const donationAmounts = [
    { amount: 500, label: '₹500', description: 'Provides meals for 5 children' },
    { amount: 1000, label: '₹1,000', description: 'Supports education for 1 child' },
    { amount: 2500, label: '₹2,500', description: 'Medical checkup for 10 children' },
    { amount: 5000, label: '₹5,000', description: 'School supplies for 20 children' }
  ];

  return (
    <section id="donate" className="py-16 px-4 dark:bg-gray-800 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 dark:text-white">How You Can Help</h2>
          <p className="text-lg dark:text-gray-300 text-gray-600 max-w-2xl mx-auto">
            Your generosity transforms lives. Every donation makes a real difference in communities across India.
          </p>
        </div>

        {/* Impact Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="dark:bg-gray-700 dark:border-gray-600 text-center">
            <CardContent className="pt-6">
              <TrendingUp className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <div className="text-3xl font-bold dark:text-white text-gray-900">100%</div>
              <p className="dark:text-gray-300 text-gray-600">Goes to Programs</p>
            </CardContent>
          </Card>
          <Card className="dark:bg-gray-700 dark:border-gray-600 text-center">
            <CardContent className="pt-6">
              <Users className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <div className="text-3xl font-bold dark:text-white text-gray-900">10,000+</div>
              <p className="dark:text-gray-300 text-gray-600">Lives Impacted</p>
            </CardContent>
          </Card>
          <Card className="dark:bg-gray-700 dark:border-gray-600 text-center">
            <CardContent className="pt-6">
              <Target className="w-12 h-12 text-purple-500 mx-auto mb-4" />
              <div className="text-3xl font-bold dark:text-white text-gray-900">15</div>
              <p className="dark:text-gray-300 text-gray-600">Communities Served</p>
            </CardContent>
          </Card>
        </div>

        {/* Donation Options */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Quick Donate */}
          <Card className="dark:bg-gray-700 dark:border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 dark:text-white">
                <Heart className="w-5 h-5 text-red-500" />
                Quick Donate
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {donationAmounts.map((donation) => (
                  <Button
                    key={donation.amount}
                    variant={selectedAmount === donation.amount ? "default" : "outline"}
                    className="h-auto p-4 flex flex-col items-start dark:hover:bg-gray-600"
                    onClick={() => handleDonation(donation.amount, 'one-time')}
                  >
                    <span className="font-bold text-lg">{donation.label}</span>
                    <span className="text-xs opacity-75">{donation.description}</span>
                  </Button>
                ))}
              </div>
              
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Custom amount"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="flex-1 dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                />
                <Button onClick={handleCustomDonation} disabled={!customAmount}>
                  Donate
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Giving */}
          <Card className="dark:bg-gray-700 dark:border-gray-600 border-2 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 dark:text-white">
                <IndianRupee className="w-5 h-5 text-blue-600" />
                Monthly Giving
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm dark:text-gray-300 text-gray-700">
                Become a monthly donor and provide sustained support for our programs.
              </p>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start dark:hover:bg-gray-600"
                  onClick={() => handleDonation(500, 'monthly')}
                >
                  ₹500/month - Education Support
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start dark:hover:bg-gray-600"
                  onClick={() => handleDonation(1000, 'monthly')}
                >
                  ₹1,000/month - Healthcare Support
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start dark:hover:bg-gray-600"
                  onClick={() => handleDonation(2500, 'monthly')}
                >
                  ₹2,500/month - Complete Care
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Information */}
        <Card className="max-w-2xl mx-auto dark:bg-gray-700 dark:border-gray-600">
          <CardHeader>
            <CardTitle className="text-center dark:text-white">Payment Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-green-50 dark:bg-green-900/20 border dark:border-green-800 border-green-200 rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold dark:text-green-400 text-green-800 mb-2">UPI Payment</h3>
                  <p className="text-2xl font-mono font-bold dark:text-green-400 text-green-700">{upiId}</p>
                  <p className="text-sm dark:text-green-300 text-green-600 mt-1">Scan any UPI app to donate</p>
                </div>
                <Button
                  onClick={copyToClipboard}
                  variant="outline"
                  className="flex items-center gap-2 dark:hover:bg-gray-600"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy UPI ID'}
                </Button>
              </div>
            </div>

            <div className="text-center space-y-2">
              <p className="text-sm dark:text-gray-300 text-gray-600">
                <strong>Bank Transfer:</strong> HopeBridge Foundation, A/C: XXXXXXXXXX, IFSC: XXXXXX
              </p>
              <p className="text-xs dark:text-gray-400 text-gray-500 italic">
                100% of donations go directly to programs. No administrative fees deducted.
              </p>
              <p className="text-xs dark:text-gray-400 text-gray-500">
                All donations are eligible for 80G tax benefits.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default Donate;