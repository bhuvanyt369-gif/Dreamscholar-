import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { User, Mail, Phone, MapPin, Send, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '../hooks/useToast';

const VolunteerForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    interest: '',
    experience: '',
    availability: '',
    motivation: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { success, error } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate form
      if (!formData.name || !formData.email || !formData.phone || !formData.location || !formData.interest || !formData.availability || !formData.motivation) {
        error('Please fill in all required fields');
        setIsSubmitting(false);
        return;
      }

      // Save to localStorage
      const volunteers = JSON.parse(localStorage.getItem('hopeBridgeVolunteers') || '[]');
      volunteers.push({
        ...formData,
        timestamp: new Date().toISOString(),
        id: Date.now(),
        status: 'pending'
      });
      localStorage.setItem('hopeBridgeVolunteers', JSON.stringify(volunteers));
      
      // Send email notification
      const subject = `New Volunteer Application: ${formData.name}`;
      const body = `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\nLocation: ${formData.location}\nInterest: ${formData.interest}\nExperience: ${formData.experience}\nAvailability: ${formData.availability}\n\nMotivation:\n${formData.motivation}`;
      
      const mailtoLink = `mailto:099bhuvan@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.open(mailtoLink, '_blank');
      
      setIsSubmitted(true);
      success('Application submitted! We will contact you within 48 hours.');
    } catch (err) {
      error('Failed to submit application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setIsSubmitted(false);
    setFormData({ 
      name: '', email: '', phone: '', location: '', 
      interest: '', experience: '', availability: '', motivation: '' 
    });
  };

  if (isSubmitted) {
    return (
      <Card className="max-w-2xl mx-auto border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800">
        <CardContent className="text-center p-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-green-800 dark:text-green-400 mb-2">Application Submitted!</h3>
          <p className="text-green-600 dark:text-green-300 mb-4">Thank you for your interest in volunteering. We'll contact you within 48 hours.</p>
          <Button onClick={resetForm} variant="outline" className="dark:hover:bg-gray-700">
            Submit Another Application
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="text-2xl text-center dark:text-white">Join Our Volunteer Team</CardTitle>
        <p className="text-center dark:text-gray-300 text-gray-600">Make a difference in your community</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="dark:text-gray-300">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
                placeholder="John Doe"
                className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              />
            </div>
            <div>
              <Label htmlFor="email" className="dark:text-gray-300">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required
                placeholder="john@example.com"
                className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone" className="dark:text-gray-300">Phone Number *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                required
                placeholder="+91 98765 43210"
                className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              />
            </div>
            <div>
              <Label htmlFor="location" className="dark:text-gray-300">Location *</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
                required
                placeholder="City, State"
                className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="interest" className="dark:text-gray-300">Area of Interest *</Label>
            <Select value={formData.interest} onValueChange={(value) => setFormData({...formData, interest: value})}>
              <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                <SelectValue placeholder="Select your interest" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="teaching">Teaching & Education</SelectItem>
                <SelectItem value="medical">Medical Support</SelectItem>
                <SelectItem value="food">Food Distribution</SelectItem>
                <SelectItem value="events">Event Organization</SelectItem>
                <SelectItem value="fundraising">Fundraising</SelectItem>
                <SelectItem value="admin">Administrative Support</SelectItem>
                <SelectItem value="social-media">Social Media & Marketing</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="experience" className="dark:text-gray-300">Relevant Experience</Label>
            <Textarea
              id="experience"
              value={formData.experience}
              onChange={(e) => setFormData({...formData, experience: e.target.value})}
              rows={3}
              placeholder="Tell us about any relevant experience..."
              className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>

          <div>
            <Label htmlFor="availability" className="dark:text-gray-300">Availability *</Label>
            <Select value={formData.availability} onValueChange={(value) => setFormData({...formData, availability: value})}>
              <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                <SelectValue placeholder="Select your availability" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekends">Weekends Only</SelectItem>
                <SelectItem value="weekdays">Weekdays Only</SelectItem>
                <SelectItem value="flexible">Flexible</SelectItem>
                <SelectItem value="specific">Specific Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="motivation" className="dark:text-gray-300">Why do you want to volunteer? *</Label>
            <Textarea
              id="motivation"
              value={formData.motivation}
              onChange={(e) => setFormData({...formData, motivation: e.target.value})}
              required
              rows={4}
              placeholder="Share your motivation for joining HopeBridge Foundation..."
              className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>
          
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Submitting...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Submit Application
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default VolunteerForm;