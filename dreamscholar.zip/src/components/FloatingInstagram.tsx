import React from 'react';
import { Instagram } from 'lucide-react';

const FloatingInstagram = () => {
  return (
    <a
      href="https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg=="
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 left-6 z-40 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 p-4 rounded-full shadow-2xl hover:scale-110 transition-all duration-300 group"
      aria-label="Follow us on Instagram"
    >
      <Instagram className="w-6 h-6 text-white" />
      <span className="absolute left-full ml-3 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-1 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        Follow us on Instagram
      </span>
    </a>
  );
};

export default FloatingInstagram;