import React from 'react';
import { Heart, Mail, Phone, MapPin, Instagram, Facebook, Twitter, Youtube, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'About Us', href: '#about' },
    { name: 'Our Mission', href: '#mission' },
    { name: 'Projects', href: '#projects' },
    { name: 'Donate', href: '#donate' },
    { name: 'Volunteer', href: '#volunteer' },
    { name: 'Contact', href: '#contact' }
  ];

  const legalLinks = [
    { name: 'Privacy Policy', href: '#' },
    { name: 'Terms of Service', href: '#' },
    { name: 'Refund Policy', href: '#' }
  ];

  const socialLinks = [
    {
      icon: Instagram,
      url: 'https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg==',
      label: 'Instagram'
    },
    {
      icon: Facebook,
      url: 'https://facebook.com/hopebridgefoundation',
      label: 'Facebook'
    },
    {
      icon: Twitter,
      url: 'https://twitter.com/hopebridge_fdn',
      label: 'Twitter'
    },
    {
      icon: Youtube,
      url: 'https://youtube.com/@hopebridgefoundation',
      label: 'YouTube'
    },
    {
      icon: Linkedin,
      url: 'https://linkedin.com/company/hopebridge-foundation',
      label: 'LinkedIn'
    }
  ];

  return (
    <footer className="dark:bg-gray-900 bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Organization Info */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Heart className="w-6 h-6 text-red-500" />
              HopeBridge Foundation
            </h3>
            <p className="dark:text-gray-300 text-gray-300 text-sm leading-relaxed">
              Together, we can save children's lives and support families in need. 
              Every donation makes a real difference in communities across India.
            </p>
            <div className="flex space-x-3">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="dark:bg-gray-800 bg-gray-800 p-2 rounded-lg hover:bg-gray-700 transition-colors"
                    aria-label={social.label}
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="dark:text-gray-300 text-gray-300 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-blue-400" />
                <a href="tel:+917702479214" className="dark:text-gray-300 text-gray-300 hover:text-white text-sm">
                  +91 7702479214
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-400" />
                <a href="mailto:099bhuvan@gmail.com" className="dark:text-gray-300 text-gray-300 hover:text-white text-sm">
                  099bhuvan@gmail.com
                </a>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-400 mt-1" />
                <span className="dark:text-gray-300 text-gray-300 text-sm">
                  Rural Outreach Center<br />
                  Madhya Pradesh, India
                </span>
              </div>
            </div>
          </div>

          {/* Newsletter & Legal */}
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-semibold mb-4">Stay Updated</h4>
              <p className="dark:text-gray-300 text-gray-300 text-sm mb-3">
                Get the latest updates on our work and impact
              </p>
              <a
                href="mailto:099bhuvan@gmail.com?subject=Newsletter%20Subscription"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors inline-block"
              >
                Subscribe to Newsletter
              </a>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Legal</h4>
              <ul className="space-y-2">
                {legalLinks.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="dark:text-gray-300 text-gray-300 hover:text-white transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t dark:border-gray-800 border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm dark:text-gray-400 text-gray-400">
              © {currentYear} HopeBridge Foundation. All rights reserved.
            </div>
            <div className="flex items-center gap-2 text-sm dark:text-gray-400 text-gray-400">
              <span>Made with</span>
              <Heart className="w-4 h-4 text-red-500" />
              <span>for humanity</span>
            </div>
            <div className="flex items-center gap-4">
              <a
                href="https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg=="
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-400 hover:text-pink-300 transition-colors text-sm flex items-center gap-1"
              >
                <Instagram className="w-4 h-4" />
                Follow us
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;