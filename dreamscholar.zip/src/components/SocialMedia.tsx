import React from 'react';
import { Instagram, Facebook, Twitter, Youtube, Linkedin } from 'lucide-react';

const SocialMedia = () => {
  const socialLinks = [
    {
      icon: Instagram,
      url: 'https://www.instagram.com/_krish_1437_?igsh=MWI3Z2QwMGR6eG51Yg==',
      label: 'Instagram',
      color: 'bg-gradient-to-r from-purple-500 to-pink-500'
    },
    {
      icon: Facebook,
      url: 'https://facebook.com/hopebridgefoundation',
      label: 'Facebook',
      color: 'bg-blue-600'
    },
    {
      icon: Twitter,
      url: 'https://twitter.com/hopebridge_fdn',
      label: 'Twitter',
      color: 'bg-sky-500'
    },
    {
      icon: Youtube,
      url: 'https://youtube.com/@hopebridgefoundation',
      label: 'YouTube',
      color: 'bg-red-600'
    },
    {
      icon: Linkedin,
      url: 'https://linkedin.com/company/hopebridge-foundation',
      label: 'LinkedIn',
      color: 'bg-blue-700'
    }
  ];

  return (
    <div className="flex justify-center space-x-4">
      {socialLinks.map((social) => {
        const Icon = social.icon;
        return (
          <a
            key={social.label}
            href={social.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`${social.color} text-white p-3 rounded-full hover:scale-110 transition-transform shadow-lg`}
            aria-label={social.label}
          >
            <Icon className="w-5 h-5" />
          </a>
        );
      })}
    </div>
  );
};

export default SocialMedia;