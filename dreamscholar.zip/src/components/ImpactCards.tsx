import React from 'react';
import { Heart, BookOpen, Award, Home } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';

const ImpactCards = () => {
  const stats = [
    {
      icon: Heart,
      number: "10,000+",
      label: "Children Fed",
      color: "text-rose-500"
    },
    {
      icon: BookOpen,
      number: "500+",
      label: "Schools Supported",
      color: "text-teal-600"
    },
    {
      icon: Award,
      number: "200+",
      label: "Medical Camps",
      color: "text-rose-500"
    },
    {
      icon: Home,
      number: "15",
      label: "Communities Empowered",
      color: "text-teal-600"
    }
  ];

  return (
    <section id="impact" className="py-16 dark:bg-gray-900 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 dark:text-white text-indigo-700">
          Our Impact So Far
        </h2>
        <div className="flex flex-wrap justify-center gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="dark:bg-gray-800 dark:border-gray-700 bg-gray-50 border-gray-200 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <stat.icon className={`w-12 h-12 mx-auto mb-4 ${stat.color}`} />
                <div className="text-3xl font-bold dark:text-white text-slate-800 mb-2">{stat.number}</div>
                <div className="dark:text-gray-300 text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImpactCards;