import React from 'react';
import { Button } from '../components/ui/button';
import { ArrowDown, Heart, Sparkles, Star } from 'lucide-react';

const Hero = () => {
  const scrollToDonate = () => {
    const donateSection = document.getElementById('donate');
    if (donateSection) {
      donateSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Hero Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=1600&h=900&fit=crop" 
          alt="Children in need" 
          className="w-full h-full object-cover"
        />
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Main Headline */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white mb-6 leading-tight tracking-tight">
          Together, we can save
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-400 drop-shadow-lg font-black">
            children's lives
          </span>
          <span className="block text-white font-black">and support families in need.</span>
        </h1>

        {/* HIGHLIGHTED TAGLINE */}
        <div className="mb-10 relative">
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-orange-400/20 to-pink-400/20 blur-xl rounded-lg"></div>
          
          <div className="relative bg-gradient-to-r from-yellow-500/10 via-orange-500/10 to-pink-500/10 backdrop-blur-sm border border-yellow-400/30 rounded-lg p-6 shadow-2xl">
            <div className="flex items-center justify-center gap-3 mb-3">
              <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
              <p className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-400 tracking-tight">
                Every Rupee Creates Hope
              </p>
              <Sparkles className="w-6 h-6 text-pink-400 animate-pulse" />
            </div>
            <p className="text-lg md:text-xl text-white/95 font-black tracking-tight">
              Your generosity transforms lives — one child, one family at a time
            </p>
            <div className="flex items-center justify-center gap-2 mt-3">
              <Star className="w-5 h-5 text-yellow-400" />
              <p className="text-white/90 text-sm font-bold italic">Join thousands making a difference today</p>
              <Star className="w-5 h-5 text-yellow-400" />
            </div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            onClick={scrollToDonate}
            className="px-8 py-4 text-lg font-black bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300 flex items-center gap-2"
          >
            <Heart className="w-5 h-5" />
            Donate Now
            <Heart className="w-5 h-5" />
          </Button>
          
          <Button 
            onClick={scrollToDonate}
            className="px-8 py-4 text-lg font-black bg-white/20 backdrop-blur-sm border-2 border-white/50 text-white hover:bg-white hover:text-indigo-700 rounded-full transition-all duration-300 flex items-center gap-2 shadow-lg"
          >
            <ArrowDown className="w-5 h-5" />
            Learn More
          </Button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-8 h-8 text-white/70" />
        </div>
      </div>
    </section>
  );
};

export default Hero;