import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import SocialMedia from './SocialMedia';

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      label: 'Phone',
      value: '+91 7702479214',
      action: 'tel:+917702479214',
      description: 'Mon-Sat, 9AM-6PM'
    },
    {
      icon: Mail,
      label: 'Email',
      value: '099bhuvan@gmail.com',
      action: 'mailto:099bhuvan@gmail.com',
      description: 'We respond within 24 hours'
    },
    {
      icon: MapPin,
      label: 'Address',
      value: 'Rural Outreach Center, Madhya Pradesh, India',
      action: 'https://maps.google.com/?q=Madhya+Pradesh+India',
      description: 'Visit us by appointment'
    },
    {
      icon: Clock,
      label: 'Office Hours',
      value: 'Monday - Saturday: 9:00 AM - 6:00 PM',
      action: '',
      description: 'Sunday: Closed'
    }
  ];

  return (
    <section id="contact" className="py-16 px-4 dark:bg-gray-800 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 dark:text-white">Get in Touch</h2>
          <p className="text-lg dark:text-gray-300 text-gray-600 max-w-2xl mx-auto">
            Have questions? Want to learn more? Reach out to us through any of these channels
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {contactInfo.map((info, index) => (
            <div
              key={index}
              className="dark:bg-gray-700 bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center"
            >
              <info.icon className="w-8 h-8 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold dark:text-white mb-2">{info.label}</h3>
              {info.action ? (
                <a
                  href={info.action}
                  className="dark:text-blue-400 text-blue-600 hover:underline block mb-2"
                >
                  {info.value}
                </a>
              ) : (
                <p className="dark:text-gray-300 text-gray-700 mb-2">{info.value}</p>
              )}
              <p className="text-sm dark:text-gray-400 text-gray-500">{info.description}</p>
            </div>
          ))}
        </div>

        <div className="dark:bg-gray-700 bg-white rounded-xl shadow-md p-8">
          <h3 className="text-xl font-semibold text-center mb-6 dark:text-white">Follow Us on Social Media</h3>
          <SocialMedia />
          <p className="text-center mt-6 dark:text-gray-300 text-gray-600">
            Stay updated with our latest activities and impact stories
          </p>
        </div>
      </div>
    </section>
  );
};

export default Contact;