import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Utensils, GraduationCap, Stethoscope, AlertTriangle, MapPin } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      icon: Utensils,
      title: "Food Distribution",
      description: "Monthly meals for 2,000 families in rural villages",
      color: "text-rose-500"
    },
    {
      icon: GraduationCap,
      title: "Child Education",
      description: "School supplies and scholarships for 500+ children",
      color: "text-teal-600"
    },
    {
      icon: Stethoscope,
      title: "Medical Support",
      description: "Free health camps and emergency medical assistance",
      color: "text-rose-500"
    },
    {
      icon: AlertTriangle,
      title: "Emergency Relief",
      description: "Rapid response during natural disasters and crises",
      color: "text-teal-600"
    },
    {
      icon: MapPin,
      title: "Community Centers",
      description: "Building safe spaces for learning and growth",
      color: "text-rose-500"
    }
  ];

  return (
    <section id="projects" className="py-16 dark:bg-gray-900 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 dark:text-white text-indigo-700">
          Our Projects
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {projects.map((project, index) => (
            <Card key={index} className="dark:bg-gray-800 dark:border-gray-700 bg-gray-50 border-gray-200 hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <project.icon className={`w-10 h-10 ${project.color} mb-2`} />
                <CardTitle className="text-lg dark:text-white">{project.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="dark:text-gray-300 text-gray-600 text-sm">{project.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;